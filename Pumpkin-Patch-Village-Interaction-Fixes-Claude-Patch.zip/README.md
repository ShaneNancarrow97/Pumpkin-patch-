# Claude contractor kit — Village Interaction Fixes

This is an incremental patch on the delivered Blackroot base. Do not replace Claude’s dirty checkout.

Base: 7bb7639523083f444da565aa5716b82282e16421
Source: 2cb6bad7cfd0be20775b86727e7242aab1867392
Expected complete tree: cbfa09f096cf2bf98b41c61eb869fbf593cccab3
Source branch: contractor/village-interaction-fixes

In a clean isolated checkout at the base, run from the Git root:

    git am patches/*.patch
    cd voxel
    npm test
    node build.mjs --out /tmp/pumpkin-interaction.html

Expected HTML SHA256: c08029b91f19cb4363b39b0fbb0bbf376dd43656eb46fbaba21b33382198d8f7

Clean replay of this actual patch was checked: the complete tree matches and the rebuilt HTML has that identical SHA. If Claude’s lead has advanced, review and port conflicting functions deliberately. First integrate the prior contractor/village-menu-refinement base if the lead does not have it.

Start with voxel/docs/contractor-patches/village-interaction-fixes/README.md. It links each complete part, the dependency matrix, tests and exact browser evidence. State format18 and original node/upgrade IDs are preserved. New tip tiers extend the existing field. The actual controller Create button binding is unchanged; its visible word is removed in favor of the user’s requested symbol.

The optional Android update is a separate additive kit, prepared after HTML/ZIP publication. No keys, uploaded API credentials, generated build cache or user saves are included.
