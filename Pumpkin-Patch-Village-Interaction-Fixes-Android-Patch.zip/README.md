# Optional Android add-on — Interaction Fixes

Apply the game kit FIRST: it brings base7bb7639523083f444da565aa5716b82282e16421 to game treecbfa09f096cf2bf98b41c61eb869fbf593cccab3/source2cb6bad7cfd0be20775b86727e7242aab1867392.

Then from that clean checkout’s Git root run git am patches/*.patch in filename order. Patch1 records the checked game downloads. Patch2 increments the Android version and adds the native reports/handover.

Expected complete source tree after both: a8a0e82a527bc78d977c55e2500bec7cb99ba7ca
Canonical source commit:4929fb9590e621737a6fd26c6729361ef9a4482a

Both patches were actually replayed after the game kit: the tree matches and the checkout is clean. Game source, assets and build script are byte-for-byte unchanged by this add-on, retaining HTMLSHA256c08029b91f19cb4363b39b0fbb0bbf376dd43656eb46fbaba21b33382198d8f7.

Read voxel/docs/contractor-patches/village-interaction-fixes/NATIVE.md for package/version, checks, build command and physical-device limits. The persistent signing key/password are intentionally excluded. No Android build is needed to integrate the normal HTML game.
