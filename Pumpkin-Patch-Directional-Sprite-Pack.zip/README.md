# Pumpkin Patch — directional characters

Open Pumpkin-Patch-Directional-Characters.html to play the full offline game. The ZIP contains the same HTML. No account, API key or server is required by the game.

This release adds eight-direction movement sheets for Shane and Natalie in their everyday clothes and nine Mothlight neighbours: Elowen, Rowan, Vesper, Mabel, Tansy, Opal, Cinder, Corvus and Baron. Each sheet has 64 movement drawings; Cinder floats. Walking follows actual distance and turns relative to the camera. Existing costumes, tool poses, idle art and pets retain their previous sheets. Eight view sectors are not the historical 15-degree target.

The standalone Sprite Preview offers direction selection and frame scrubbing. The Sprite Pack ZIP includes final source sheets, runtime atlases, metadata and a portable preview; the Claude Patch ZIP contains the incremental source patch and full handover. Repair inputs are retained in the source repository.

Source branch: contractor/directional-character-sheets at ShaneNancarrow97/Pumpkin-patch-. Handover: voxel/docs/contractor-patches/directional-character-sheets/README.md. The incremental patch requires the Living Mothlight parent commit 8901e18df05367d7ce38f3e0da775d07ce877a21; do not apply it blindly to another branch.

Export your current farm using Settings → Save to a file before moving to a different browser or file origin. Save format is unchanged. Automated browser checks do not certify physical Fold, Bluetooth or TV hardware.

BUILD.json records source provenance and exact file hashes.

Run `python3 voxel/tools/bake-directional-sprites.py` with Pillow to rebuild from the final source sheets. The complete repair history is in the Git source/Claude patch, rather than duplicated here.
