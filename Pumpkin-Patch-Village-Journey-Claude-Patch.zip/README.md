# Village Journey — Claude contractor patch kit

Five ordered binary-capable patches reproduce source commit e61180ffd2f7a9304a0af6feb330eff4b8f34c4b from fa3ce1616919d3e75b0488421d42c7df50f0df31. That parent is the previous directional-character contractor handover, not an arbitrary main branch. Full source is pushed on contractor/village-journey; latest documentation/verification commits may follow this code commit.

## Inspect without disturbing current work

    git fetch origin contractor/village-journey
    git worktree add ../review-village-journey origin/contractor/village-journey

Review handover/README.md and its dependency matrix before merging shared main.js, scene.js, village, save and UI adapters into independently edited lead code. Preserve Claude's current uncommitted work. Do not reset, auto-merge or run these patches over a different parent.

## Reproduce the five-patch code snapshot

In a clean separate worktree exactly at fa3ce1616919d3e75b0488421d42c7df50f0df31:

    git am /absolute/path/to/patches/*.patch
    cd voxel
    npm ci
    npm test
    node build.mjs --out /absolute/path/Pumpkin-Patch-Village-Journey.html

Clean replay was verified: resulting tree 4090296e3795314ad4ad1dcea98a7783b7764384 and HTML SHA256 f6a755b2b692f899d132df07b148dacba229711c8a1c67a7d8bcdeacaacf2edd. All 904 automated tests pass. Existing parent dependencies are required, including main-game content imported by voxel rules.

## Parts to inspect

1. dc6725e: 36 illustrated village item icons, shared atlas, pure helpers.
2. 7e1df6b: physical farm/village travel, larger Green, relocating foraging, quest HUD, village-earned progression, away farm rate2.5→10%, empty-handed idle.
3. 8eb5c12: five supplied MIDIs, 26-track catalogue, selective silent-tail trimming.
4. 1fa44e5: 128 repaired base walking cells, measured stride, shared grass detail.
5. e61180f: nearby-only villagers, 8 furniture illustrations, real truck service, additional till tiers, saved fountain seeds/stars/rewards.

The package includes the complete source/binary changes and source art through those commits. Final browser receipts and downloadable artifacts are on the two contractor branches; use their exact hashes. Voice recordings are unchanged; new tour/quest lines have subtitles and explicit pending recording entries. No API key or online runtime service is included.

Save version 18 preserves older owned items/progression. Existing village pieces overlapping reserved resource sites return to storage; ownership is retained. Export an existing farm from Settings before moving file/browser origin. Only base owner walking is repaired; full costume/action/15-degree coverage remains future work.
