# Claude patch — directional characters

This incremental two-patch series adds eight-direction movement art for Shane and Natalie in everyday clothes and the nine Mothlight neighbours. It also connects camera-relative facing and distance-driven gait to controlled/autonomous movement, preserves existing costume/action fallbacks and fixes shared sprite geometry being disposed during room changes.

Required parent: `8901e18df05367d7ce38f3e0da775d07ce877a21` (Living Mothlight).

Runtime/art commit: `c2b6a409120fca3b2e1c9bc29e65316ed8570b1e`.

Runtime/art tree (first patch): `2a82ada8f828c243b1484e677c34845c1c0bfba9`.

The first patch was applied in a clean worktree at that parent. Its resulting tree matches the runtime/art commit and its HTML build is byte-identical to the download. The second patch supplies the final QA harness correction, documentation and verification evidence; it does not alter the game bundle. `patch-apply.json` records the evidence.

## Review separately from active work

```sh
git fetch origin contractor/directional-character-sheets
git worktree add -b review/directional-characters ../pumpkin-direction-review 8901e18df05367d7ce38f3e0da775d07ce877a21
cd ../pumpkin-direction-review
git am /absolute/path/to/this-kit/patches/*.patch
cd voxel
npm ci
npm test
npm run build
```

Asset tests/baking need Pillow 10–12. The game itself remains one offline HTML with no new runtime dependency.

If Claude's branch already contains equivalent parent changes under different commits, inspect `DEPENDENCIES.md` and integrate the adapters on a review branch. The exact-parent replay does not establish conflict-free application to an independently edited branch. The source branch contains the complete ancestry for review.

## Scope

Eleven sheets contain 704 movement drawings; Cinder uses floating phases. Existing costumes, pets, idle/greeting and tool poses retain their own art. These are eight painted viewing sectors, not 15-degree views or a rig-certified animation library. Front footfall repairs, sources and measurement metadata are included in the patch. No saved-state, economy, quest or control-binding changes are made.

Read `HANDOVER.md`, `COVERAGE.md` and `DEPENDENCIES.md`. Verification records distinguish scripted pose inspection, real keyboard input, accelerated route simulation and browser viewport emulation. Physical Fold, Bluetooth and TV hardware were not tested.

Verification commit: `7b62cb651eb318229414e2a76fa8d6cd1f538e95`.
