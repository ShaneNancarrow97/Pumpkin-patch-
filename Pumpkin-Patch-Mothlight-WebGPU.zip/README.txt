PUMPKIN PATCH — MOTHLIGHT WEBGPU

Extract this ZIP and open index.html in Chrome or Edge. The complete offline
game, assets and existing audio are embedded in that HTML file. No API key is
needed. A compatible secure browser can select WebGPU for the village; devices
or origins without a usable adapter keep the original WebGL renderer. Local
file/content URLs may use WebGL. The farm, house, rides and canonical village
map snapshot retain WebGL. Menus and controls stay in HTML/CSS.

The village gains actual neighbouring-voxel ambient occlusion, shared physical
material atlases, explicit node shader ports, HDR bloom and colour grading,
while keeping instanced geometry and the existing single paced game loop.
The inherited fidelity pass adds the detailed lantern gateway, dusk clouds,
fine stonework and compact plum-and-brass journal and dialogue panels.

Save version 20, stories, rewards, resources and economy are retained. Export
your farm in Settings > Save, then import it here if this extracted file is a
different browser/save origin. Earlier downloads and saves are not overwritten.

Claude: read Claude-Handover.md, Claude-Fidelity-Handover.md and verification/.
Review contractor/village-webgpu without overwriting unpublished lead work.
Canonical handover:
https://github.com/ShaneNancarrow97/Pumpkin-patch-/blob/e99cd6e84d409e318392db2019d407487abba4ee/voxel/docs/contractor-patches/village-webgpu/README.md

preview/webgpu-release and preview/webgl-release contain actual captures of
this exact final HTML, with the real backend recorded in the evidence.
preview/fidelity-checkpoint contains THREE OLDER dialogue layout captures:
desktop, TV and phone from HTML SHA-256 6c71a20fd4858fbd4fb99e4aeae71e79a1350d37c138be7e0818b916208ecc63.
They are labelled as the earlier fidelity checkpoint, not new WebGPU captures.
PREVIEW-PROVENANCE.json records every picture's hash and source HTML.

Software GPU and injected controller checks establish execution and layout;
they do not certify physical phone, TV, Bluetooth or hardware FPS.
No new APK is included. The earlier APK predates this renderer release.

Source: e99cd6e84d409e318392db2019d407487abba4ee
Runtime: b1915b64c111b4085a91997e7a35208bb3565813
HTML bytes: 61710319
HTML SHA-256: 56dc1a9a99b354c46ac9b8beef379a769669171e34c10cecf9d53a55cf88f849
Tests: 1483 passed, 0 failed
Exact final GPU checks: 20; WebGL checks: 11; compatibility: 54
Independent source rebuild: byte-identical
The external download receipt adds the ZIP's byte count and SHA-256.
