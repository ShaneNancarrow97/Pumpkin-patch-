# Village Play Polish — Claude contractor patch

Apply the three ordered binary-capable patches only to a separate clean checkout exactly at ff6b5803686c449b902d405037f8958d03e3e2d8 (previous Village Journey handover). Do not apply blindly to independently edited lead code. Full branch: contractor/village-play-polish.

    git am /absolute/path/patches/*.patch
    cd voxel
    npm ci
    npm test
    node build.mjs --out /absolute/path/game.html

Read handover/README.md and its dependency matrix before merging main, scene, player/input, world/map and UI adapters. Claude's dirty checkout and lead branch were untouched. Base save format 18 remains unchanged. All 961 automated tests pass; browser reports distinguish exactbuilds and the finalCSSdelta.

Patch1: generated village/home navigation art, finer grass and vector controller glyphs. Patch2: safe travel, close follow, farmR3 camera, spatial map/criteria, worldvisibility/glows, 2–3roamers, contextual controls, premiumjournal/dialogue/building, cursor/scroll retention, quieter music and periodic farm reminder. Patch3: balanced one-row furniture legend on wide screens.

No Android wrapper is included in these three game patches; Android packaging follows after the game is verified. Source branch will retain its separate Android handover/commit for review. Pending future districts remain honestly locked; this patch is not an implementation of those later chapters.
