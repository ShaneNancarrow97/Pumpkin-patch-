# Village Play Polish — Claude game contractor kit

Apply the 5 ordered binary-capable patches only to a separate clean checkout at `ff6b5803686c449b902d405037f8958d03e3e2d8`. They replay the complete isolated contractor game branch through `8bf4d53b530fd835c20f4515e76913b376b295c9`. Review shared files against Claude's independent work; do not overwrite his checkout.

    git am /absolute/path/patches/*.patch
    cd voxel
    npm ci
    npm test
    node build.mjs --out /absolute/path/game.html

Read handover/README.md, FARM-ENTRANCE.md and SHARED-EXIT-DELIVERY.md for the dependency matrix, current shared public exit and precise validation. Save format remains18. The generated game must have SHA-256 `9314af490ecceb32d030b6ac57772927a15013790f910146ff27ccaf0d54ce17`.

Patches1–3 add UI art, controls/camera/travel/world polish and the balanced build legend. Patch4 records exact-hash verification tools/evidence. Patch5 uses the existing public exit past Maisie and clears its narrow forest sightline, with final checks. All prior reports retain their real original hashes.

Android is a separate final contractor addition under voxel/android on the source branch, supplied alongside this game kit after HTML/ZIP publication. It is not needed to build or play the standalone HTML. Future village districts remain honestly locked.
