Shane & Natalie’s Pumpkin Patch — Village Menu Refinement

Open index.html in current Chrome, Edge or Safari. All game art, music and voices are embedded; no server is needed. Use the full-screen button in the top bar after opening the game.

Farm controller: L2 opens the top/action/bottom bars; D-pad or left stick moves; Cross selects; Circle or L2 returns to play. Options keeps the broader menu hub. R3 retains farm camera mode. Village controls keep their separate mapping. The PS5 legend highlights nearby actions, D-pad Up expands the followed quest, and Options opens village menus. Menu prompts show D-pad Navigate, Cross Select and Circle Back.

Tap the illustrated level badge for exact requirements and reward previews. Reward cards distinguish free gifts from upgrades available to purchase. L1/R1, arrows or swipes browse the cards. The Village shortcut has its own painted bottom-bar icon.

Use Settings to export your save before switching browsers, files or the Android app, and import it in the destination. Different file origins may keep different browser storage. Save version remains18.

This is an isolated contractor build for Claude to review. Hardware Fold7/TV/Bluetooth certification is not claimed. See the contractor source handover for test fixtures, software-rendering scope and patch order.

Music:31 songs, including your supplied Dancing in the Moonlight, Bitter Sweet Symphony, Duality, Paint It Black and Fireflies. Choose them in Settings or use Shuffle.
