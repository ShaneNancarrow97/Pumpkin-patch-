Pumpkin Patch — Village Clarity

Open index.html in your browser. The game assets, music and existing narration are embedded for offline play.

The village map now shows the actual saved voxel world through a tilted orthographic camera, with selectable location markers, inline requirements and optional neighbour pins. This build also improves village interactions, purple menus, keyboard/controller legends and completion notices, and repairs missing puzzle choices.

To move an existing farm between downloaded versions or browser origins, export it from Settings in the old build, then import that save in Settings here. Save version remains20; existing progression and coins are retained.

Source: https://github.com/ShaneNancarrow97/Pumpkin-patch-/tree/ac16208b9dcdf4d0d22da67c8b0b2aab6c968487
Claude handover: https://github.com/ShaneNancarrow97/Pumpkin-patch-/blob/ac16208b9dcdf4d0d22da67c8b0b2aab6c968487/voxel/docs/contractor-patches/village-clarity/README.md
Review PR: https://github.com/ShaneNancarrow97/Pumpkin-patch-/pull/3

1,269 tests and54 exact-build compatibility checks pass. Final map checks ran with normal software rendering at DPR2. Preview images show the declared progressed test farm, not your personal save. The map in your game follows your saved restoration and decoration state.

See verification/ for the precise test scopes and mixed software timing results. No physical-device FPS or updated APK claim is made.
