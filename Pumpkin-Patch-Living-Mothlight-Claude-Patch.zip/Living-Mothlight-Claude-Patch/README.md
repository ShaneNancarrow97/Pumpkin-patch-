# Living Mothlight: Claude patch kit

Two alternative patch series are included. **Apply one series only, in a clean isolated checkout.**

- `patches/`: four new commits, for the existing voiced contractor base `e2cd697a993ae46d372420d7f966c1b99b5519ab`.
- `from-voxel-reference/`: eleven commits, for Claude’s checked lead `604fe2359427fc7e90a3d1248a6c4d1d6b0136c8`. Includes the earlier painted cast, saved village bridge and recorded voices as prerequisites.

Use `git am path/to/chosen-series/*.patch`. If your branch has additional changes, merge/review `contractor/mothlight-living-village` instead of applying this kit blindly. Do not apply both series or apply patches after merging the same work.

Both series have been applied in a disposable clean checkout and produce code tree `18203904edd79829f499ebacde0c73f6a8431386`. The incremental replay builds the exact delivered HTML SHA-256 in BUILD.json. There is no save-version or dependency change. No provider credential is included or required.

Read DESIGN-AND-DEPENDENCIES.md for interaction boundaries and ROADMAP.md for future work. The source branch’s `voxel/docs/contractor-patches/mothlight-living-village/` contains the full handover, tests and screenshots. Runtime patch commits deliberately exclude this release’s large QA screenshots.

Build: `cd voxel`, `npm ci`, `npm test`, `npm run build`. Output: `dist/pumpkin-patch-voxel.html`.
