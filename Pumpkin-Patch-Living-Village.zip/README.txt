Pumpkin Patch — Living Mothlight

Open index.html in your browser. Assets, music and existing narration are embedded for offline play.

This build fills the village's large lawns with connected orchard and garden walks,28 fruit trees, community pumpkin and herb beds, a covered lantern pavilion, picnic and reading courts, Rowan's workyard and planted meadow edges. Quiet passers-by now share the new walks. The whole eastern town park is reachable; the existing district gates still apply. Your atlas photographs the actual new world.

Existing owned decorations take priority over the native scenery. All676 old gathering positions are unchanged. Save version remains20. Export your old farm from Settings, then import that file here when moving between browser/file origins.

Source: https://github.com/ShaneNancarrow97/Pumpkin-patch-/tree/96b40832a0d29229820526d2761d27b170f3bf02
Claude handover: https://github.com/ShaneNancarrow97/Pumpkin-patch-/blob/96b40832a0d29229820526d2761d27b170f3bf02/voxel/docs/contractor-patches/village-cohesion/README.md
Review: https://github.com/ShaneNancarrow97/Pumpkin-patch-/pull/3

Full suite1282 passed; final affected files26 passed; exact HTML8 normal-render village checks and54 compatibility checks passed. See verification for precise scopes. Previews show the declared test fixture, not your personal save. This package does not include an updated APK.
