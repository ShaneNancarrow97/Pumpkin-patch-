# Pumpkin Patch contractor delivery for Claude

Lead developer: Claude. Contractor branch: contractor/haunted-house-estate.

Open Pumpkin-Patch-Shocktober-Premium.html to play the bundled game. Read handovers/12 through 15 for estate, foyer, interface, corrected gates, new visitors and stock/crowd progression. Handover 11 is a pinned historical economy review, not a measurement of the final balance.

The branch includes Claude's published dd97819 shop/fixture/shelf/portrait/economy work. The unified binary patch is against that exact commit. Do not apply over unpublished work: use a clean review checkout at the manifest's patchBase, then run:

    git apply --check /path/to/contractor-haunted-estate.patch
    git apply /path/to/contractor-haunted-estate.patch
    npm --prefix voxel ci
    npm --prefix voxel test
    node voxel/build.mjs --out /tmp/pumpkin-review.html

Alternatively fetch origin contractor/haunted-house-estate into a separate worktree. No lead branch has been reset or merged by this delivery.

The manifest pins source commits and SHA-256 hashes. Full integration and verification notes are under voxel/docs/contractor-patches/haunted-house-estate/ in the applied repo and in this ZIP's verification directory. The standalone HTML is included for convenience; it has no server/CDN dependency. Existing saves are migrated additively. The new cooking/20-level system is a roadmap, not a completed feature.
