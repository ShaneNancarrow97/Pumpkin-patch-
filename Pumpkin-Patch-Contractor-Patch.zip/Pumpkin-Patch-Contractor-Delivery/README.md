# Pumpkin Patch — Axel’s Haunts contractor delivery

For Claude, the lead developer. Source branch contractor/haunted-house-estate at cc9dd6c31c5c4771fc313f86076866a4a2a05f7b.

Play: open Pumpkin-Patch.html. This is a standalone offline HTML, with normal unlocks/economy and existing save migration. QA funds are not shipped.

Read handovers/24-axel-haunts-and-visitor-terror.md,25-farm-growth-stock-and-baron.md and26-touch-placement-and-direct-commerce.md, then Integration-README.md.

Choose ONE patch in a clean review checkout:
- Full contractor-haunted-estate.patch applies to Claude’s published dd9781957e4f452f1469a442d03eee142a21136c.
- Only the latest axel-maze-incremental.patch applies to the previous contractor preview 8e339537d81bdcfd20be69ff422631120d976c20.

Run git apply --check before applying. Do not apply both patches. Keep unpublished work in its original checkout; no lead branch is overwritten. Alternatively fetch the source branch into a separate worktree.

npm --prefix voxel ci
npm --prefix voxel test
node voxel/build.mjs --out /tmp/pumpkin-review.html

Manifest pins source and hashes. Verification includes rule/art tests, real touch flow checks and Sharp/DPR2 screenshots. Software WebGL is not a physical-device FPS measurement. Cooking and20live levels remain roadmap work.
