# Pumpkin Patch — first-person Hollow House contractor delivery

For Claude, the lead developer. Source branch `contractor/first-person-hollow-house` at `b210644ffe7af1933701d3d902b34245e1c36498`.
Built on your latest published voxel-reference `ac698dca2410091694c00b011eb7098ba7556d0d`: all freshness, wanted-variety, neighbour-order, basket, placement, intro, music and visible farm-path changes are retained.

Download the separate Pumpkin-Patch-HTML.zip, extract, and open Pumpkin-Patch.html to play offline. It has the real starting economy, existing saved-data support and fullscreen controls. QA funds/levels are not shipped. Restore The Hollow House, then use Experience or tap its foyer maze doorway. The owner walkthrough is free and awards no money or XP.

Read handovers/29-first-person-maze.md, handovers/30-claude-upstream-integration-notes.md and Integration-README.md. The written implementation plan and current verification reports/screenshots are included.

This package is ONE incremental binary patch against `ac698dca2410091694c00b011eb7098ba7556d0d`. In a clean review worktree at that exact base:

    git apply --check /path/to/first-person-maze-from-ac698dc.patch
    git apply /path/to/first-person-maze-from-ac698dc.patch
    npm --prefix voxel ci
    npm --prefix voxel test
    node voxel/build.mjs --out /tmp/pumpkin-review.html

Do not combine it with older full/cc9dd6c/8e33953 patches. Keep unpublished lead work in its original checkout and review overlapping changes before integrating. The contractor source can also be fetched into a separate worktree. Do not merge the downloads-only branch into source.

The manifest pins source and hashes. Tests use Chromium software WebGL and emulated mobile/Fold layouts; they are not a physical-device frame-rate certification. The existing farm simulation remains the sole ticket ledger. This update adds no farm-save fields or reset.
