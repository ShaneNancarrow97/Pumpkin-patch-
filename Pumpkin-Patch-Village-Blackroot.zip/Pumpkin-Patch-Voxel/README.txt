Shane & Natalie’s Pumpkin Patch — Blackroot Village

Open index.html in current Chrome/Edge/Safari; all artwork, music and voices are embedded. Use the top-bar full-screen button. Export your current farm in Settings before changing browser/file origins or moving to Android, then import in the destination. Version18 saves are preserved.

Village dialogue now uses a low speech ribbon and icon-led choices. The camera frames your character and the actual villager, then returns to exploration. Cross selects and Circle goes back; touch choices use one tap. Choices offer actual chats, quests, presents and neighbour details.

The Blackroot story begins after the invitation at level3, with further chapters at5 and8. Find and root out cursed fungus, study sealed samples and help the farm recover. A full spore satchel still permits clearing; bonus samples are discarded. Recipes and house rewards arrive once through the existing quest system. New patches never displace old furniture.

The followed quest uses a portrait/checklist; D-pad Up or T expands it. Quest and Menus remain on the village legend; basic movement legends are removed. Left stick still moves and right stick still looks. Farm L2 opens top/action/bottom bars, D-pad navigates, Cross selects, Circle/L2 returns; R3 retains farm camera mode.

The catalogue has31 MIDI songs, including your five newest uploads, available through Settings/Shuffle. Existing recordings remain; new Blackroot lines are readable dialogue with the existing narration fallback, not new provider recordings.

This is an isolated contractor build for Claude to review. Viewport/mocked-pad tests do not certify physical Fold7/TV/PS5 Bluetooth or hardware frame rate. The source handover records exact test hashes and limits.
