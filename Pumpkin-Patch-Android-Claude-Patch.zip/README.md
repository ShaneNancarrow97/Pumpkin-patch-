# Claude Android contractor addendum

Apply this one binary-capable patch AFTER the five game patches, on a clean separate checkout at `8bf4d53b530fd835c20f4515e76913b376b295c9`. It reaches `3b42a9a1f7ff6b0a1fe51f6e33f1fdca13988d72`. Alternatively fetch `contractor/village-play-polish`. Claude's working checkout was not changed.

    git am /absolute/path/patches/*.patch

The android/ folder is a convenient source/reference copy; the patch places it under voxel/android with delivery receipts. Read ANDROID-HANDOVER.md and android/README.md. Rebuild from the checked final game HTML with the hash recorded in ANDROID-PATCHKIT.json. The browser HTML/game rules remain unchanged.

The signed APK was built AFTER game/UI/world jobs, checks, HTML/ZIP publication and full public hash verification. Its packaged binary media is identical to the browser artwork/audio; the APK document is smaller. This remains WebView/WebGL2. Six extraction and ten shell tests and package/signature/media checks passed. The emulator's storage/provider failure prevented install/launch verification; actual Fold/TV/Bluetooth QA remains.

Private signing key/password and generated game assets are deliberately excluded. Obtain the existing signing material privately to preserve in-place app updates; otherwise export a save before reinstalling. This is a locally test-signed build, not Play Store publication.
