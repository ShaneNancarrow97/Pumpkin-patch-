# Claude contractor patch kit — Mothlight Expansion

This is a complete two-commit contractor package. It does not overwrite your working checkout.

Base: 8048fd32e5dbdf33b81d38c78c07b05ecef5be7f
Target: 5852e0bc1aa10a8a9fb2134693b7bc9c88db6cd7
Branch: contractor/mothlight-full-expansion

Review in a clean worktree at the exact base, then run `git am patches/*.patch` in filename order. If Claude has additional changes, inspect/cherry-pick deliberately and use the dependency matrix to resolve overlaps. No reset/force-push is required. The clean replay's Git tree and rebuilt HTML were verified byte-identical; PATCHKIT.json records the proof.

Read voxel/docs/contractor-patches/mothlight-full-expansion/README.md after applying. Each completed part has its own handover: CORE, CAST-COMPANIONS, WORLD, ECONOMY, RUNTIME, ART, VOICE-INVENTORY and QA-RUNNER. DELIVERY.md links actual final evidence.

The two patches contain the full game implementation, retained generated-art sources, tests, build integration and final verification. Existing saved data is preserved by additive version19 migration. No API credential, private signing key, node_modules or game save is included.

From voxel/: npm install if needed; npm test; node build.mjs --out /tmp/mothlight.html. See QA-RUNNER.md for exact-HTML browser checks. Native Android follows as a separate optional addendum after game publication.
