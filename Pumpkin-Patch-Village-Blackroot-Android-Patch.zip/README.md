# Claude optional Android addendum — Blackroot

Apply the one patch after the complete9-patch Blackroot game kit (base f4ffe28d11b0eaa1dfd4c9903a523bb78d862eb2). It changes native sources/reports and delivery docs only. The browser game does not need it. Current host sources are also under source/voxel/android for review.

The app packages the exact checked browser HTML e98d2ffc583051836aa21f33eccb04559ea413b4e4ebec31bd4cc8cd529abaaf, after public HTML/ZIP/game-kit verification. All276 media bytes remain identical; local media extraction reduces the HTML document to4,574,536bytes (92.2446% fewer parse bytes). WebView/WebGL2 still renders the game.

Version26110802 /2026.11.08.2 keeps the previous appID and workspace-local signing identity. Native Back dismisses a visible level receipt before leaving a place or offering to quit. Package version metadata comes from the manifest.11 shell and6 extractor tests plus signature/alignment/ZIP CRC/all-media checks pass. Physical Fold7/TV/PS5 Bluetooth installation/performance remains unverified; the prior emulator limitation is documented.

The private signing key/password are not in Git or this kit. Retain/recover them privately for in-place updates. With a different identity, export the farm before uninstalling and import afterward. See source/voxel/android/README.md and ANDROID.md for exact rebuild commands. This is a locally test-signed app, not a Play Store release.
