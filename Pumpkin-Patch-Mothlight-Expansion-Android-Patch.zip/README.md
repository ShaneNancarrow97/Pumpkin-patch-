# Optional Android addendum for Claude

Apply after the complete Mothlight two-patch game kit (source tree at5852e0b). Run git am patches/*.patch in filename order in the same review worktree. These patches add the verified game-publication receipt and the Android version/evidence update. No game runtime changes or private signing material are included.

Read voxel/docs/contractor-patches/mothlight-full-expansion/NATIVE.md. This APK packages the exact checked ab6ac3af HTML, after game downloads were published. Version2026.11.09.2 / code26110902 retains the previous signing identity and application ID.17 native/extraction tests, signature, alignment, CRC and all media hashes pass.

Native means an offline Android System WebView/WebGL2 host with local cached assets, not a native3D rewrite. Physical installation, Fold7/TV/Bluetooth and hardware performance remain unverified. Native PATCHKIT.json records identical clean-replay/source trees. Final public-download receipt commits may follow separately and do not change behavior.
