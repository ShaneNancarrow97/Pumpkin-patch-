PUMPKIN PATCH — MOTHLIGHT COUTURE

Extract the ZIP and open index.html. It contains the complete offline game,
artwork and existing audio. No API key or separate asset download is needed.

The village's journal, conversations, neighbours, satchel, workshop, stall,
discovery pages, map and Build controls share plum parchment, antique-gold
frames and illustrated controls. Existing story, reward, inventory, purchase,
decorating and controller actions are retained. Saves remain version 20.

Rendering is unchanged from e99cd6e: village WebGPU capability selection with WebGL fallback; farm, house, rides and map use WebGL. This UI release is checked with actual software WebGL, not a new WebGPU/device performance certification.

Export your farm in Settings > Save, then import it here if the extracted file
is a different browser/save origin. Prior downloads are preserved. No new APK.

Claude: read Claude-Handover.md and verification/ for the dependency matrix.
Source: 248217094354059a35fd9379189e4940d79776b5
Frozen runtime: 6f6666a015666cdb15d3cde4dde2dadff0788ae9
Incremental review base: e99cd6e84d409e318392db2019d407487abba4ee
Branch: contractor/village-ui-couture
HTML bytes: 61789302
HTML SHA-256: 232535a2d4fdb6a3273314b8f152e10a175ae8db1ff7bbdbe81d3d725d2e1290
Independent source rebuild: byte-identical
Tests: 1489 passed, 0 failed
Exact-HTML browser checks: 88 passed in separately scoped runs:
  7 native-render hero checks;
  81 broad HTML/CSS/input checks with world draws explicitly held.

preview/native-render contains actual live-render captures of this exact HTML:
desktop journal, nearby Rowan dialogue and portrait journal.
preview/ui-only contains a clearly labelled stall interface capture. Its world
draws were held; it verifies HTML/CSS/input, not current camera/world pixels.
Every image records its own provenance and exact HTML hash in BUILD-RECEIPT.
The external receipt adds the ZIP hash; the ZIP's internal receipt cannot
include its own hash. Physical Bluetooth and device FPS are not certified.
