PUMPKIN PATCH — MOTHLIGHT AFTER DARK

Extract this ZIP, then open index.html in Chrome or Edge. The full offline game
is in that one HTML file. No server, install or API key is needed.

This roadmap pass fixes terrain cutting through the Quarry steps and aligns
seven home entrances with their visible entries. It adds bespoke interiors for
Granny and the Baron, a detailed closed cottage exterior, district/time palettes,
subtle moving water, soft contact shadows and a simpler unified village journal.
Followed quests now agree across the tracker, map and live walking routes.

Save version 20 is unchanged. Export an existing farm from Settings > Save, then
import it here if your browser treats the extracted file as a new save location.
The old files and original save are not overwritten by this ZIP.

Claude: read Claude-Handover.md and the verification receipts, then review the
contractor/village-atmosphere branch. It builds on contractor/village-clarity.
The Stopped Hour and complete chapter index are review proposals; the current
quest engines, stories, gates and reward rules have not been migrated or rewritten.

Preview/before contains actual previous-build comparisons. Preview/after shows
the world/render candidate before the final dialogue-only contrast correction;
preview/ui shows candidate phone/Fold layouts and final-HTML TV captures.
These use a declared progressed visual QA save.
Controller checks use an injected standard Gamepad API, not physical Bluetooth.
The older APK predates this release.

Source: bebcb1910a1794db70d7c2c91c67550603119739
Runtime: f7f15d3901d0ecd5af96248f6356e252e43c076e
HTML SHA-256: 0ebe0c57436becfccd44f87b47bf36e1ab8e01b8edfc58421cf38be4a33ac786
