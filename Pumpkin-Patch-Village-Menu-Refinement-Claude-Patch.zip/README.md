# Claude contractor kit — Village menus, farm space and level rewards

Base: 50afb77c5596189c57c48c7c8a4c379e9baa4b97, the previous delivered Village Play Polish source.
Source branch: contractor/village-menu-refinement.

Use a separate checkout. From the base above, apply patches/ in filename order with git am. PATCHKIT.json records the exact target tree and HTML hash. If your lead branch has changed since that base, review and port conflicts deliberately; do not replace shared files wholesale.

1. Clear Skyla’s public shop path and align Maisie’s queue/tables/seats with the rendered layout.
2. Refine village pages, conversation focus and Back history; add illustrated level rewards, a Village shortcut icon and L2 farm-bar navigation.
3. Keep requirements at the top while reward dots scroll horizontally; make village Quest/Menu shortcuts and D-pad menu prompts explicit.
4. Improve highlighted Cross contrast; include handover, dependency matrix and exact-hash verification.
5. Add all five new original MIDI uploads to the existing Settings selector and shuffle catalogue (31 songs).
6. Record final catalogue/browser evidence and updated download hashes.

Read handover/README.md, LEVELS.md, QUESTS.md, CONVERSATIONS.md, FARM-CORNER.md, FARM-CONTROLLER.md LEVEL-ART.md and MUSIC.md. Game save version18, economy and reward-grant rules are preserved. The runtime rank/reward art and Village icon are compressed; source artwork, prompts and bakers are in the patches.

Verification is split by exact artifact: 995 full UI-source Node checks plus6 focused final MIDI/audio tests and31-track audit; 105 integrated checks and54 standard smoke checks on the preceding candidate; 35 focused functional/legend checks on a77; final388 is only the high-contrast glyph CSS delta with its own normal photographs and color/geometry checks. Failed staging/measurement attempts are labelled and retained. Mocked-pad/software-viewport checks do not certify hardware or Bluetooth.

Run npm ci, npm test and npm run build in voxel/ after applying. The clean replay already produced byte-identical final HTML. The latest HTML/ZIP download links are in handover/DELIVERY.md.

Android is an OPTIONAL separate addendum published after the game downloads. It is not needed to review or merge the browser game. Its private signing identity is never included in Git or this kit.

Screenshot binaries are stored once in the ordered source patches. The readable handover copy keeps reports and documentation; applying the patches restores the complete verification image tree. The approved TV/menu images are also separate public downloads.
