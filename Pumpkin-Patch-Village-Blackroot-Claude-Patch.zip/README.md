# Claude contractor kit — Blackroot village and cinematic dialogue

Latest source branch: contractor/village-menu-refinement.
Base:50afb77c5596189c57c48c7c8a4c379e9baa4b97 (previous Village Play Polish delivery).

Apply all nine patches in filename order with git am in an isolated checkout. PATCHKIT.json records exact target tree, source head and checked HTML. Port conflicts deliberately if the lead has advanced, particularly village-game/view, resource/quest tables and the stylesheet list. The lead working checkout was untouched.

Parts1–6 deliver farm space, menu/navigation refinement, level reward art/cards, L2 bar navigation, five supplied MIDI tracks and initial evidence. Part7 adds Blackroot content/rules/detailed voxel patches and the camera helper; part8 connects cinematic greeting/action dialogue and quest controls; part9 verifies rendering and constrains the TV grid so Back/footer remain reachable.

Start with handover/README.md and BLACKROOT-DELIVERY.md. DIALOGUE.md, DIALOGUE-CAMERA.md, QUEST-TRACKER.md, BLIGHT.md, BLIGHT-WORLD.md and BLIGHT-ART.md describe the new reference-driven UI, actual-character framing, three level3/5/8 quest chapters, full-satchel cleanup, legacy-furniture preservation and detailed727-box domed fungus. MUSIC.md describes the31-song catalogue.

The functional source passes1035 named Node tests. Exact final e98 TV stylesheet delta passes12 browser child-bounds/controller/long-text checks. Earlier integration/camera/model evidence retains its actual hashes and visual findings. Hardware Fold7/TV/Bluetooth and performance certification is not implied by software viewports/mock input. Existing164 voice recordings are retained; new lines use normal fallback and their pending inventory is exact.

Nine patches replay to the recorded exact source tree and rebuild byte-identical final HTML. Run npm ci, npm test and npm run build from voxel/. Save format18, old quests/claims and existing furniture are preserved. No new persistent schema fields were added.

Screenshot binaries are stored once in the patches; the readable handover copy retains reports/docs. Applying patches restores the full image evidence tree. Approved dialogue/fungus screenshots are also public downloads. Android is an optional separate source addendum, packaged after the checked game. No private signing key/password is included.
