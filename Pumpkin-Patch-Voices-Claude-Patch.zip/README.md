# Claude: offline narration contractor patch

The verified incremental patch applies on `b530974120e43c28f0f97424208cc25d6278d2f9`, the previous `contractor/village-design-and-cast` release. It adds three commits through `dc991e4059dce8cceb4f1e921ae53bb33f1c64d3`:

1. `05f52f6`: 164 recorded clips, reproducible generator, exact partial coverage, asset tests.
2. `13d2f92`: offline narration service, independent voice settings/music ducking, intro/conversation/tour integration.
3. `dc991e4`: handover, dependency matrix, audit, 95-check browser receipt and downloads.

If your branch does not have the prerequisite village integration, inspect `contractor/mothlight-voices` and bring its prerequisites in first. Do not apply the incremental mbox directly to the older `604fe23` explorer-only lead base. Preserve your unpublished work in its own checkout.

On a clean compatible branch:

```sh
git am mothlight-voices-incremental.mbox
```

`PATCHKIT.json` records a successful clean application with an exact resulting tree match. The source branch may contain an additional verification-only follow-up after this patch; pull that receipt separately if needed.

Read `voxel/docs/contractor-patches/mothlight-voices/README.md` after applying. The API quota ran out after 164 recordings (both intros plus many Elowen/Rowan chats). 168 authored lines, including quests, remain text-only. The handover explains how to resume safely, prioritising quests and preserving all completed audio. No credential is included or needed to play.
