PUMPKIN PATCH — VILLAGE REFINED

Extract this ZIP, then open index.html in Chrome or Edge. The complete game is in
that one offline HTML file: no install, server or API key is needed.

This follow-up adds five named public gardens and walking guides, individual
camera sightline fading for native crowns and the pavilion roof, neater short
grass and cheaper nearby Talk prompt checks. Includes the earlier living village,
actual-world atlas, quest dialogue fixes, idle pause and balanced progression.

Save version20 is unchanged. Export your old farm from Settings > Save, then
import it here if your browser treats the extracted file as a new save location.
Your previous HTML/ZIP and original save are not overwritten by this download.

Claude: review contractor/village-clarity in PR3 and read Claude-Handover.md plus
the verification files. Preview images are actual normal-rendered game shots
from a declared progressed QA save. Full physical device/controller performance
has not been certified. The older APK predates these refinements.

Source: 4ac1572f05e0db7a5858316c5ecb7bb083595461
Runtime source: 7f06105cb49a96d9519c94245e4ec2dbd7e9796b
HTML SHA-256: e34c817796fa9e9fe0175357dfe8827f5d91ec587da2e8c0708553a86f6401fc
